let exchangeRateNBU = null;
let exchangeRateDeal = null;

const rateFieldAPIName = 'Currency_Rate';
const nbuUrl = 'https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?valcode=USD&json';

document.addEventListener('DOMContentLoaded', function () {
  getExchangeRate();
});

function getExchangeRate() {
  fetch(nbuUrl)
    .then(response => response.json())
    .then(nbuData => {
      if (Array.isArray(nbuData) && nbuData.length > 0) {
        exchangeRateNBU = nbuData[0].rate;
        document.getElementById("nbu-rate").textContent = exchangeRateNBU.toFixed(2);

        // ⚠️ Для локального тесту — мок значення угоди:
        exchangeRateDeal = 35.5;
        document.getElementById("deal-rate").textContent = exchangeRateDeal.toFixed(2);

        const diffPercent = ((exchangeRateDeal / exchangeRateNBU - 1) * 100).toFixed(1);
        document.getElementById("diff").textContent = `${diffPercent}%`;

        if (Math.abs(diffPercent) >= 5) {
          document.getElementById("update-btn").style.display = "inline-block";
        }

      } else {
        throw new Error("Неправильна відповідь НБУ");
      }
    })
    .catch(err => {
      console.error("Помилка:", err);
      document.getElementById("log").textContent = "Не вдалося отримати курс.";
    });
}